# pptx_to_pdf
A Python package to convert PowerPoint presentations (PPTX) to PDF by exporting slides to images and combining them.

## Installation
```bash
pip install pptx_to_pdf
